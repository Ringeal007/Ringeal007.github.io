
# Warmatap   

由 Mikutap 进行二次创作

修改自 [HFIProgramming/mikutap](https://github.com/HFIProgramming/mikutap)

原作者 [daniwell@aidn.jp](https://aidn.jp/mikutap)

二次创作 MonianHello 2022.4

# 版权说明  

声音素材已获得B站UP主Warma授权

遵循原作者的说明，作品仅用于非盈利的公共使用用途，无需告知  

商业用途请直接联系作者，[详情](https://aidn.jp/about/)

```
daniwell@aidn.jp
※ 本サイトにて公開している楽曲は非営利かつ公序良俗に反しない限り、連絡なしにご自由にお使いいただいて構いません。
※ エグジットチューンズ管理楽曲（「Nyan Cat」や「ねこみみスイッチ」など）の商用利用につきましては、下記お問い合わせ窓口よりご連絡ください。
http://exittunes.com/license/
```


# DEMO  
my Blog:[http://124.223.50.254/warmatap/](http://124.223.50.254/warmatap/)

GithubPage:[https://monianhello.github.io/WarmaTap/](https://monianhello.github.io/WarmaTap/)
